﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerCollision : MonoBehaviour
{
	public playerMovement movement;
	
	void OnCollisionEnter(Collision col) {
		if(col.collider.tag == "Obstacle"){
			Debug.Log("Hit");
			movement.enabled = false;
		}
	}
}
